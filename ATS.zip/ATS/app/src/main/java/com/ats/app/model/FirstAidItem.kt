package com.ats.app.model

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
data class FirstAidItem(
    val title: String,
    val actions: List<String> = listOf(),
    val noPoints: Boolean = false
) : Parcelable