package com.ats.app.activity

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.ats.app.FirstAidListAdapter
import com.ats.app.databinding.ActivityFirstAidListBinding
import com.ats.app.model.FirstAidItem
import com.ats.app.utils.Constants
import com.ats.app.utils.FirstAidListGenerator
import kotlinx.android.synthetic.main.activity_first_aid_list.*

class FirstAidListActivity : AppCompatActivity() {

    private val binding: ActivityFirstAidListBinding by lazy {
        ActivityFirstAidListBinding.inflate(layoutInflater)
    }

    val firstAidList: ArrayList<FirstAidItem> = arrayListOf()

    private val adapter: FirstAidListAdapter by lazy {
        FirstAidListAdapter()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        supportActionBar?.elevation = 0f
        supportActionBar?.title = ""
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        firstAidList.addAll(FirstAidListGenerator.getFirstAidList(this))
    }

    override fun onSupportNavigateUp(): Boolean {
        finish()
        return super.onSupportNavigateUp()
    }

    override fun onStart() {
        super.onStart()
        rvList.adapter = adapter
        adapter.setItems(firstAidList)
        adapter.onItemClick {
            openDetailsScreen(it)
        }
    }

    private fun openDetailsScreen(item: FirstAidItem) {
        startActivity(Intent(this, FirstAidDetailActivity::class.java).apply {
            putExtra(Constants.INTENT_KEY_FIRST_AID_ITEM, item)
        })
    }
}
