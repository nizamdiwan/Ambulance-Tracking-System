package com.ats.app.model.remote

import android.util.Log
import com.google.gson.GsonBuilder
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.create

object ApiServiceBuilder {

    val apiService: ApiService = Retrofit.Builder()
        .baseUrl("https://maps.googleapis.com/maps/api/")
        .addConverterFactory(GsonConverterFactory.create(GsonBuilder().setLenient().create()))
        .client(
            OkHttpClient.Builder()
                .addNetworkInterceptor(HttpLoggingInterceptor(object :
                    HttpLoggingInterceptor.Logger {
                    override fun log(message: String) {
                        Log.e("SERVER", message)
                    }
                }).apply {
                    level = HttpLoggingInterceptor.Level.BODY
                })
                .build()
        )
        .build().create()
}