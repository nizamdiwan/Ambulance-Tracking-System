package com.ats.app

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.ats.app.databinding.FirstAidPointItemBinding


class FirstAidInstructionsListAdapter(private val list: ArrayList<String> = arrayListOf()) :
    RecyclerView.Adapter<FirstAidInsVH>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FirstAidInsVH {
        return FirstAidInsVH(
            FirstAidPointItemBinding.inflate(
                LayoutInflater.from(parent.context),
                parent,
                false
            )
        )
    }

    override fun getItemCount(): Int = list.size

    override fun onBindViewHolder(holder: FirstAidInsVH, position: Int) {
        holder.bind(list[position])
    }

    fun setItems(data: List<String>) {
        list.clear()
        list.addAll(data)
        notifyDataSetChanged()
    }

}

class FirstAidInsVH(val binding: FirstAidPointItemBinding) :
    RecyclerView.ViewHolder(binding.root) {
    fun bind(item: String) {
        binding.tvText.text = item
    }
}