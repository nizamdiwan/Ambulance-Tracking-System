package com.ats.app.activity

import android.content.Intent
import android.location.Location
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.ats.app.BuildConfig
import com.ats.app.PlacesResultAdapter
import com.ats.app.R
import com.ats.app.ResultAction
import com.ats.app.databinding.ActivityFindBinding
import com.ats.app.model.remote.ApiServiceBuilder
import com.ats.app.model.remote.PlaceResult
import com.ats.app.model.remote.PlacesSearchResponse
import com.ats.app.utils.Constants
import com.ats.app.utils.FindType
import com.birjuvachhani.locus.Locus
import com.google.android.libraries.places.api.Places
import com.google.android.libraries.places.api.net.PlacesClient
import kotlinx.android.synthetic.main.activity_find.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext


class FindActivity : AppCompatActivity() {

    private val binding: ActivityFindBinding by lazy {
        ActivityFindBinding.inflate(layoutInflater)
    }

    private val placesClient: PlacesClient by lazy {
        Places.createClient(this)
    }

    private val scope: CoroutineScope = CoroutineScope(Dispatchers.IO)

    companion object {
        const val TAG = "FindActivity"
    }

    private var type: FindType = FindType.HOSPITAL

    private val adapter: PlacesResultAdapter by lazy {
        PlacesResultAdapter()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        supportActionBar?.title = ""
        supportActionBar?.elevation = 0f
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        type =
            intent?.extras?.getSerializable(Constants.INTENT_KEY_FIND_TYPE) as? FindType ?: return
        when (type) {
            FindType.HOSPITAL -> {
                binding.tvTitle.text = getString(R.string.hospitals)
            }
            FindType.PHARMACY -> {
                binding.tvTitle.text = getString(R.string.pharmacies)
            }
        }
        Locus.getCurrentLocation(this) {
            it.location?.let(::searchPlaces)
        }
        rvList.adapter = adapter
    }

    private fun searchPlaces(location: Location) {
        adapter.currentLocation = location
        scope.launch {
            kotlin.runCatching {
                val result: PlacesSearchResponse = ApiServiceBuilder.apiService.getNearbyPlaces(
                    key = BuildConfig.PLACES_KEY,
                    location = "${location.latitude},${location.longitude}",
                    radius = 50_000,
                    type = type.name.toLowerCase()
                )
                withContext(Dispatchers.Main) {
                    binding.progressBar.visibility = View.GONE
                }
                result.results?.let {
                    withContext(Dispatchers.Main) {
                        loadList(it)
                    }
                } ?: run {
                    withContext(Dispatchers.Main) {
                        binding.progressBar.visibility = View.GONE
                        binding.rvList.visibility = View.GONE
                        binding.errorText.text = "Unable to Load"
                        binding.errorContainer.visibility = View.VISIBLE
                    }
                }
            }.onFailure {
                Log.e(TAG, it.message)
                withContext(Dispatchers.Main) {
                    binding.progressBar.visibility = View.GONE
                    binding.rvList.visibility = View.GONE
                    binding.errorText.text = "Unable to Load"
                    binding.errorContainer.visibility = View.VISIBLE
                }
            }
        }
    }

    private fun loadList(list: List<PlaceResult>) {
        if (list.isEmpty()) {
            binding.errorText.text = "No Result Found"
            binding.rvList.visibility = View.GONE
            return
        }
        adapter.onItemClick { result, action ->
            openMapsApp(result, action)
        }
        adapter.setData(list)
    }

    private fun openMapsApp(placeResult: PlaceResult, action: ResultAction) {
        when (action) {
            ResultAction.NAVIGATION -> {
                Log.e(TAG, "clicked: ${placeResult.name}")
                val lat = placeResult.geometry?.location?.lat ?: return
                val long = placeResult.geometry.location.lng ?: return
                val gmmIntentUri: Uri = Uri.parse("google.navigation:q=$lat,$long")
                val mapIntent = Intent(Intent.ACTION_VIEW, gmmIntentUri)
                mapIntent.setPackage("com.google.android.apps.maps")
                startActivity(mapIntent)
            }
            ResultAction.MAP -> {
                Log.e(TAG, "clicked: ${placeResult.name}")
                val lat = placeResult.geometry?.location?.lat ?: return
                val long = placeResult.geometry.location.lng ?: return
                val intent = Intent(
                    Intent.ACTION_VIEW,
                    Uri.parse("http://maps.google.com/maps?daddr=$lat,$long")
                )
                startActivity(intent)
            }
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        finish()
        return super.onSupportNavigateUp()
    }
}
