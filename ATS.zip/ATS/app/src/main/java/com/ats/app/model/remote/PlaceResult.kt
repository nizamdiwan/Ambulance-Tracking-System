package com.ats.app.model.remote


import com.google.gson.annotations.SerializedName

data class PlaceResult(
    @SerializedName("geometry")
    val geometry: Geometry?,
    @SerializedName("icon")
    val icon: String?,
    @SerializedName("id")
    val id: String?,
    @SerializedName("name")
    val name: String?,
    @SerializedName("opening_hours")
    val openingHours: OpeningHours?,
    @SerializedName("photos")
    val photos: List<Photo>?,
    @SerializedName("place_id")
    val placeId: String?,
    @SerializedName("plus_code")
    val plusCode: PlusCode?,
    @SerializedName("rating")
    val rating: Float?,
    @SerializedName("reference")
    val reference: String?,
    @SerializedName("scope")
    val scope: String?,
    @SerializedName("types")
    val types: List<String>?,
    @SerializedName("user_ratings_total")
    val userRatingsTotal: Float?,
    @SerializedName("vicinity")
    val vicinity: String?
)