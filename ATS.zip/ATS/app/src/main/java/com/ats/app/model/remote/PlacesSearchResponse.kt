package com.ats.app.model.remote


import com.google.gson.annotations.SerializedName

data class PlacesSearchResponse(
    @SerializedName("html_attributions")
    val htmlAttributions: List<Any>?,
    @SerializedName("next_page_token")
    val nextPageToken: String?,
    @SerializedName("results")
    val results: List<PlaceResult>?,
    @SerializedName("status")
    val status: String?
)