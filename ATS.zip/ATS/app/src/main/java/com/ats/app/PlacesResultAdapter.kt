package com.ats.app

import android.location.Location
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.ats.app.databinding.PlacesResultItemBinding
import com.ats.app.model.remote.PlaceResult

enum class ResultAction { NAVIGATION, MAP }

class PlacesResultAdapter : RecyclerView.Adapter<PlacesResultVH>() {

    private var listener: (PlaceResult, ResultAction) -> Unit = { _, _ -> }
    private val list: ArrayList<PlaceResult> = arrayListOf()

    var currentLocation: Location? = null

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PlacesResultVH {
        return PlacesResultVH(
            PlacesResultItemBinding.inflate(
                LayoutInflater.from(parent.context),
                parent,
                false
            )
        )
    }

    override fun getItemCount(): Int {
        return list.size
    }

    override fun onBindViewHolder(holder: PlacesResultVH, position: Int) {
        holder.bind(list[position], listener, currentLocation)
    }

    fun setData(data: List<PlaceResult>) {
        list.clear()
        list.addAll(data)
        notifyDataSetChanged()
    }

    fun onItemClick(func: (PlaceResult, ResultAction) -> Unit) {
        listener = func
    }
}

class PlacesResultVH(val binding: PlacesResultItemBinding) : RecyclerView.ViewHolder(binding.root) {
    fun bind(item: PlaceResult, onClick:  (PlaceResult, ResultAction) -> Unit = { _, _ -> }, currentLocation: Location?) {
        binding.tvTitle.text = item.name.toString()
        binding.btnOpenMap.setOnClickListener {
            onClick(item,ResultAction.MAP)
        }
        binding.btnOpenNavigation.setOnClickListener {
            onClick(item,ResultAction.NAVIGATION)
        }
        currentLocation ?: return
        val loc = item.geometry?.location ?: return
        val lat = loc.lat ?: return
        val long = loc.lng ?: return
        val result = floatArrayOf(1f, 2f)
        Location.distanceBetween(
            currentLocation.latitude,
            currentLocation.longitude,
            lat,
            long,
            result
        )
        binding.tvDistance.text = "%.2f KM".format(result[0] / 1000)
    }
}