package com.ats.app.model.remote

import com.ats.app.model.remote.direction.DirectionsResponse
import retrofit2.http.GET
import retrofit2.http.Query

interface ApiService {

    @GET("place/nearbysearch/json")
    suspend fun getNearbyPlaces(
        @Query("key") key: String,
        @Query("type") type: String,
        @Query("location") location: String,
        @Query("radius") radius: Int
    ): PlacesSearchResponse

    @GET("directions/json")
    suspend fun getDirection(
        @Query("key") key: String,
        @Query("origin") origin: String,
        @Query("destination") destination: String
    ): DirectionsResponse
}