package com.ats.app.model.remote


import com.google.gson.annotations.SerializedName

data class PlaceLocation(
    @SerializedName("lat")
    val lat: Double?,
    @SerializedName("lng")
    val lng: Double?
)