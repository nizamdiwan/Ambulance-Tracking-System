package com.ats.app.activity

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.ats.app.BuildConfig
import com.ats.app.databinding.ActivityMainBinding
import com.ats.app.utils.Constants
import com.ats.app.utils.FindType
import com.google.android.libraries.places.api.Places

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        Places.initialize(applicationContext, BuildConfig.PLACES_KEY)
    }

    fun openFindPharmacyScreen(view: View) {
        startActivity(Intent(this, FindActivity::class.java).apply {
            putExtra(Constants.INTENT_KEY_FIND_TYPE, FindType.PHARMACY)
        })
    }

    fun openFindHospitalScreen(view: View) {
        startActivity(Intent(this, FindActivity::class.java).apply {
            putExtra(Constants.INTENT_KEY_FIND_TYPE, FindType.HOSPITAL)
        })
    }

    fun openFindFirstAidScreen(view: View) {
        startActivity(Intent(this, FirstAidListActivity::class.java))
    }

    fun openRegistrationScreen(view: View) {
        startActivity(Intent(this, EnterRegistrationIdActivity::class.java))
    }
}
