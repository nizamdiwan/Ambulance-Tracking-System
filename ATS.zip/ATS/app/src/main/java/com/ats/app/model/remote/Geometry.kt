package com.ats.app.model.remote


import com.google.gson.annotations.SerializedName

data class Geometry(
    @SerializedName("location")
    val location: PlaceLocation?,
    @SerializedName("viewport")
    val viewport: Viewport?
)