package com.ats.app.activity

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.ats.app.R
import kotlinx.coroutines.*

class SplashActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)
    }

    override fun onResume() {
        super.onResume()
        GlobalScope.launch {
            delay(2000)
            withContext(Dispatchers.Main) {
                navigateNext()
            }
        }
    }

    private fun navigateNext() {
        startActivity(Intent(this, MainActivity::class.java))
        finish()
    }
}
