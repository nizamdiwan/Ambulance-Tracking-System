package com.ats.app.activity

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.ats.app.FirstAidInstructionsListAdapter
import com.ats.app.databinding.ActivityFirstAidDetailBinding
import com.ats.app.model.FirstAidItem
import com.ats.app.utils.Constants
import kotlinx.android.synthetic.main.activity_first_aid_detail.*

class FirstAidDetailActivity : AppCompatActivity() {

    private val binding: ActivityFirstAidDetailBinding by lazy {
        ActivityFirstAidDetailBinding.inflate(layoutInflater)
    }

    private val adapter: FirstAidInstructionsListAdapter by lazy {
        FirstAidInstructionsListAdapter()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        supportActionBar?.elevation = 0f
        supportActionBar?.title = ""
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        val item: FirstAidItem =
            intent?.getParcelableExtra<FirstAidItem>(Constants.INTENT_KEY_FIRST_AID_ITEM) ?: return
        binding.tvTitle.text = item.title.replace("For ", "")
        rvList.adapter = adapter
        adapter.setItems(item.actions)
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressed()
        return super.onSupportNavigateUp()
    }
}
