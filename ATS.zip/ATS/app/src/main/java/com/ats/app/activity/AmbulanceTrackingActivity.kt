package com.ats.app.activity

import android.graphics.Color
import android.location.Location
import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.ats.app.BuildConfig
import com.ats.app.R
import com.ats.app.databinding.ActivityAmbulanceTrackingBinding
import com.ats.app.model.remote.ApiServiceBuilder
import com.ats.app.model.remote.PlacesSearchResponse
import com.ats.app.model.remote.direction.DirectionsResponse
import com.birjuvachhani.locus.Locus
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.*
import kotlinx.android.synthetic.main.activity_ambulance_tracking.*
import kotlinx.coroutines.*
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.random.Random


class AmbulanceTrackingActivity : AppCompatActivity(), OnMapReadyCallback {

    private lateinit var mMap: GoogleMap

    private val scope = CoroutineScope(Dispatchers.IO)

    private val binding: ActivityAmbulanceTrackingBinding by lazy {
        ActivityAmbulanceTrackingBinding.inflate(layoutInflater)
    }

    private var currentMarker: Marker? = null
    private lateinit var currentLocation: Location

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        supportActionBar?.title = "Tracking"
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        val mapFragment = supportFragmentManager
            .findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync(this)
    }

    @ExperimentalStdlibApi
    private fun startTracking() {
        Locus.getCurrentLocation(this) {
            it.location?.let { loc ->
                currentLocation = loc
                searchPlace(loc)
                Log.e("INFO", "Got location. calculating points")
            } ?: run {
                showErrorDialog()
                Log.e("ERROR", "Unable to get current location")
            }
        }
    }

    @ExperimentalStdlibApi
    private fun searchPlace(location: Location) {
        scope.launch {
            kotlin.runCatching {
                val result: PlacesSearchResponse = ApiServiceBuilder.apiService.getNearbyPlaces(
                    key = BuildConfig.PLACES_KEY,
                    location = "${location.latitude},${location.longitude}",
                    radius = 15_000,
                    type = "hospital"
                )
                result.results?.randomOrNull()?.geometry?.location?.let {
                    withContext(Dispatchers.Main) {
                        applyDirections(location, LatLng(it.lat!!, it.lng!!))
                    }
                } ?: run {
                    withContext(Dispatchers.Main) {
                        val point =
                            getLocationPoints(location, 0.015, Random.nextInt(0, 360).toFloat())
                        Log.e("INFO", "setting marker on $result")
                        mMap.animateCamera(
                            CameraUpdateFactory.newLatLngZoom(
                                LatLng(
                                    point.latitude,
                                    point.longitude
                                ), 15f
                            )
                        )
                        applyDirections(location, point)
                    }
                }
            }.onFailure {
                Log.e("ERROR", it.message.toString())
                withContext(Dispatchers.Main) {
                    showErrorDialog()
                }
            }
        }
    }

    @ExperimentalStdlibApi
    private fun applyDirections(loc: Location, result: LatLng) {
        scope.launch {
            runCatching {
                val directionResult = ApiServiceBuilder.apiService.getDirection(
                    key = BuildConfig.PLACES_KEY,
                    origin = "${result.latitude},${result.longitude}",
                    destination = "${loc.latitude},${loc.longitude}"
                )
                withContext(Dispatchers.Main) {
                    if (directionResult.routes?.get(0)?.legs?.get(0)?.steps?.isNotEmpty() == true) {
                        drawPath(directionResult)
                        showDirectionsOnMap(directionResult)
                    }
                }
            }.onFailure {
                withContext(Dispatchers.Main) {
                    Log.e("ERROR", it.message.toString())
                    Log.e("TOAST", "showing toast")
                    showErrorDialog()
                }
            }
        }
    }

    @ExperimentalStdlibApi
    private fun showErrorDialog() {
        AlertDialog.Builder(this@AmbulanceTrackingActivity)
            .setTitle("Unable to track")
            .setMessage("Please check your internet connection and make sure that you have allowed location permission")
            .setPositiveButton("Retry") { dialog, _ ->
                dialog.dismiss()
                startTracking()
            }.create().show()
    }

    private fun drawPath(result: DirectionsResponse) {
        val steps =
            result.routes?.firstOrNull()?.legs?.firstOrNull()?.steps?.filterNotNull() ?: return
        steps.forEach {
            Log.e("INFO", "Adding polyline")
            mMap.addPolyline(
                PolylineOptions()
                    .add(
                        it.startLocation?.let { LatLng(it.lat!!, it.lng!!) },
                        it.endLocation?.let { LatLng(it.lat!!, it.lng!!) })
                    .width(8f)
                    .color(Color.BLUE)

            )
        }
    }

    private fun showDirectionsOnMap(result: DirectionsResponse) {
        val points = arrayListOf<LatLng>()
        result.routes?.get(0)?.legs?.get(0)?.steps?.forEach {
            it ?: return
            val subPoints = getPointsBetween(
                x0 = it.startLocation?.lat!!,
                y0 = it.startLocation.lng!!,
                x1 = it.endLocation?.lat!!,
                y1 = it.endLocation.lng!!
            )
            points.addAll(subPoints)
//            val point = LatLng(it.startLocation?.lat!!, it.startLocation.lng!!)
//            points.add(point)
//            Log.e("INFO", "Point added: ${point.latitude},${point.longitude}")
        }
        // adding last point
        result.routes?.get(0)?.legs?.get(0)?.endLocation?.let {
            points.add(LatLng(it.lat!!, it.lng!!))
        }
        scope.launch {
            points.forEach {
                delay(5000)
                Log.e("INFO", "updating marker")
                withContext(Dispatchers.Main) {
                    moveMarkerTo(it)
                }
            }
        }
    }

    private fun moveMarkerTo(loc: LatLng) {
//        mMap.animateCamera(CameraUpdateFactory.zoomTo(15f), 2000, null)
        val marker = currentMarker
        if (marker == null) {
            val markerOptions = MarkerOptions()
                .position(loc)
                .icon(BitmapDescriptorFactory.fromResource(R.drawable.marker))
                .title("Ambulance")
            currentMarker = mMap.addMarker(markerOptions)
        } else {
            marker.position = loc
        }
        mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(loc, 17f))
        // calculate distance
        val distance = floatArrayOf(1f, 2f)
        Location.distanceBetween(
            currentLocation.latitude,
            currentLocation.longitude,
            loc.latitude,
            loc.longitude,
            distance
        )
        tvDistance.text = "%.2f KM".format(distance[0] / 1000)

        // calculate time
        val timeInHour = (distance[0] / 1000) / 30
        tvTime.text = "${(timeInHour * 60).toInt().toString()} min"

        binding.progressBar.visibility = View.GONE
        binding.detailsView.visibility = View.VISIBLE
    }

    private fun getPointsBetween(
        x0: Double, y0: Double, x1: Double, y1: Double
    ): ArrayList<LatLng> {
        val points = arrayListOf<LatLng>()
        val distance = sqrt(((x1 - x0) * (x1 - x0)) + ((y1 - y0) * (y1 - y0)))
        val partDistance = distance / 5
        repeat(5) {
            val t = ((it * partDistance) + partDistance) / distance

            val xt = (1 - t) * x0 + (t * x1)
            val yt = (1 - t) * y0 + (t * y1)
            points.add(LatLng(xt, yt))
        }
        return points
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressed()
        return super.onSupportNavigateUp()
    }

    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @ExperimentalStdlibApi
    override fun onMapReady(googleMap: GoogleMap) {
        mMap = googleMap
        mMap.isMyLocationEnabled = true
        startTracking()
    }

    override fun onDestroy() {
        super.onDestroy()
        scope.cancel()
    }
}

fun getLocationPoints(
    currentLocation: Location,
    radius: Double,
    degrees: Float
): LatLng {
    val lat = currentLocation.latitude + radius * cos(degrees * Math.PI / 180)
    val lng = currentLocation.longitude + radius * sin(degrees * Math.PI / 180)
    return LatLng(lat, lng)
}