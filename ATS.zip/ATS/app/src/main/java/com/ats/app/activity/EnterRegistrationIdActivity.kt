package com.ats.app.activity

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.core.widget.addTextChangedListener
import com.ats.app.databinding.ActivityEnterRegistrationIdBinding

class EnterRegistrationIdActivity : AppCompatActivity() {

    private val binding: ActivityEnterRegistrationIdBinding by lazy {
        ActivityEnterRegistrationIdBinding.inflate(layoutInflater)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        supportActionBar?.title = ""
        supportActionBar?.elevation = 0f
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        binding.etRegId.addTextChangedListener {
            binding.btnGo.isEnabled = !it?.toString().isNullOrEmpty()
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressed()
        return super.onSupportNavigateUp()
    }

    fun openTrackingActivity(v: View) {
        startActivity(Intent(this, AmbulanceTrackingActivity::class.java))
    }
}
