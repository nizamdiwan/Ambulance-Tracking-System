package com.ats.app.utils

object Constants {
    const val INTENT_KEY_FIRST_AID_ITEM = "first_aid_item"
    const val INTENT_KEY_FIND_TYPE = "find_type"
}

enum class FindType {
    PHARMACY, HOSPITAL
}
