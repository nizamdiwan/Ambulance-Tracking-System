package com.ats.app.utils

import android.content.Context
import com.ats.app.R
import com.ats.app.model.FirstAidItem


object FirstAidListGenerator {
    val firstAidData: List<Int> = listOf(
        R.array.first_aid_bandage,
        R.array.first_aid_burns,
        R.array.first_aid_cpr,
        R.array.first_aid_bee_sting,
        R.array.first_aid_nose_bleed,
        R.array.first_aid_heatstroke,
        R.array.first_aid_heart_attack,
        R.array.first_aid_babies
    )

    fun getFirstAidList(context: Context): List<FirstAidItem> {
        return firstAidData.map { resID ->
            context.resources!!.getStringArray(resID).let { arr ->
                FirstAidItem(
                    title = arr[0],
                    actions = arr.drop(1),
                    noPoints = arr.size <= 2
                )
            }
        }
    }
}