package com.ats.app

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.ats.app.databinding.FirstAidItemBinding
import com.ats.app.model.FirstAidItem


class FirstAidListAdapter(private val list: ArrayList<FirstAidItem> = arrayListOf()) :
    RecyclerView.Adapter<FirstAidVH>() {

    private var listener: (FirstAidItem) -> Unit = {}

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FirstAidVH {
        return FirstAidVH(
            FirstAidItemBinding.inflate(
                LayoutInflater.from(parent.context),
                parent,
                false
            )
        )
    }

    override fun getItemCount(): Int = list.size

    override fun onBindViewHolder(holder: FirstAidVH, position: Int) {
        holder.bind(list[position], onClick = listener)
    }

    fun setItems(data: List<FirstAidItem>) {
        list.clear()
        list.addAll(data)
        notifyDataSetChanged()
    }

    fun onItemClick(event: (FirstAidItem) -> Unit) {
        listener = event
    }

}

class FirstAidVH(val binding: FirstAidItemBinding) :
    RecyclerView.ViewHolder(binding.root) {
    fun bind(item: FirstAidItem, onClick: (FirstAidItem) -> Unit) {
        binding.tvTitle.text = item.title
        binding.root.setOnClickListener {
            onClick(item)
        }
    }
}