# ATS - Ambulance Tracking System

## Requirements to run this project

- Android Studio 3.6 or later
- Gradle 5.6.4 or later
- Google Api Key enabled for Google Maps, Places and Directions

This project uses places and direction api keys enabled for `HTTPS`  
requests and Maps api enabled for Android devices.

To set api keys, follow below instructions.

## Setting Places & Directions API key

1. This project uses the same key for making `HTTPS` requests for getting
places and directions data. So create an API key on Google GCP platform
with access of directions and places api with `HTTPS` enabled.

2. Open `local.properties` file in the project root and add following
line at the end of the file. Replace `<YOUR_API_KEY>` with your generated
api key.

```groovy
places_key="<YOUR_API_KEY>"
```

## Setting Maps API key

Same api key can be used to allow maps access or you can set a different
api key.

1. Open `app>src>debug>res>values>google_maps_api.xml` file and replace
`YOUR_API_KEY` with your generated api key. Follow given instructions in
this file to restrict the key for your project only. This api key will
be used for creating debug builds for development purposes.

2. Open `app>src>release>res>values>google_maps_api.xml` file and replace
`YOUR_API_KEY` with your generated api key. This api key will be used
for release builds that are aimed to publish on play store.

